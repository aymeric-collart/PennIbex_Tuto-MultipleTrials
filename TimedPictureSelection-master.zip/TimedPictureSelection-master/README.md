# TimedPictureSelection
Two pictures side-by-side while a sentence unfolds: use the verb's tense for early picture selection
